import Bar from './Bar';
import './navbar.css'
function Navbar(){
    return(
        <>
        <div className='container1'>
            <div className='upper'>
                <div className='bar'>
                    <Bar/>
                 </div>
            </div>
            <div className='lower'>

            </div>
    </div>
    </>
    );
    
}
export default Navbar;