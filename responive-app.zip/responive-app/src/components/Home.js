import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <div className='home-div'>
      <div className='div1'>
        <div className='container' id="container-1">
          <h1>How-to-Use</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In facilisis bibendum lorem eget sodales. Aliquam ut mauris elit. Donec eget ipsum eget neque scelerisque facilisis non a nibh. Nam bibendum consectetur consequat. Donec eu fringilla justo. Praesent a arcu et ex dictum maximus. In nunc quam, efficitur vitae mi nec, varius finibus purus. Nullam nibh turpis, congue quis neque non, facilisis luctus mi. Aenean vel risus vitae sapien rhoncus hendrerit. Praesent a lacus enim. In ut iaculis purus. Curabitur eget dui et nunc dignissim condimentum eu eu felis. Morbi quis ultrices leo. Donec facilisis consectetur velit, in facilisis justo gravida id.</p>
        </div>
        <div className='lower'></div>
      </div>
      <div className='div2'>
         <div className='container' id="container-1">
          <h1>How-to-Use</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In facilisis bibendum lorem eget sodales. Aliquam ut mauris elit. Donec eget ipsum eget neque scelerisque facilisis non a nibh. Nam bibendum consectetur consequat. Donec eu fringilla justo. Praesent a arcu et ex dictum maximus. In nunc quam, efficitur vitae mi nec, varius finibus purus. Nullam nibh turpis, congue quis neque non, facilisis luctus mi. Aenean vel risus vitae sapien rhoncus hendrerit. Praesent a lacus enim. In ut iaculis purus. Curabitur eget dui et nunc dignissim condimentum eu eu felis. Morbi quis ultrices leo. Donec facilisis consectetur velit, in facilisis justo gravida id.</p>
          </div>
          <div className='lower'></div>
      </div>
    </div>
    
  );
};

export default Home;
