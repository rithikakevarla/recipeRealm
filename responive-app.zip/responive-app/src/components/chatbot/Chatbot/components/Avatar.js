import React from 'react'

export default function Avatar() {

    return (
        <div className='ADE' >ADE</div>
    )
}
