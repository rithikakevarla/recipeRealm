import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  return (
    <div className='AboutUs-div'>
      <h1>AboutUs</h1>
    </div>
  );
};

export default AboutUs;
