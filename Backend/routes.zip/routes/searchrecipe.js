const searchrecipe = (req, res) => {
    console.log(req.body); // Accessing req.body as an object, not as a function
    res.send("Search Recipe reached");
};

export default searchrecipe